+++
title = 'Wick_for_education'
date = 2024-04-17T09:54:12-07:00
draft = true
+++
